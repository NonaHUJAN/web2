<?php 
	$host = "localhost";
	$dbname = "tiya_buku";
	$username = "root";
	$password = " ";
	$db = "";


	
 ?>