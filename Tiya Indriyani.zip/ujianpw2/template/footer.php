                   </div>
                    <!-- /.col-lg-12 -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="template/assets/js/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="template/assets/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="template/assets/js/metisMenu.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="template/assets/js/sb-admin-2.js"></script>

</body>

</html>
